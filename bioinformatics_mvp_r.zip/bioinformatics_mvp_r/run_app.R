#!/usr/bin/env Rscript
#' 生物信息学分析平台启动脚本
#'
#' @description 启动生物信息学分析平台
#' @export

# 加载必要的包
library(shiny)

# 设置工作目录
setwd(dirname(sys.frame(1)$ofile))

# 启动Shiny应用
cat("启动智能生物信息学分析平台...\n")
cat("访问地址: http://localhost:8080\n")
cat("按 Ctrl+C 停止服务\n\n")

# 启动应用
shiny::runApp(
  appDir = "app",
  host = "0.0.0.0",
  port = 8080,
  launch.browser = TRUE,
  display.mode = "normal"
)