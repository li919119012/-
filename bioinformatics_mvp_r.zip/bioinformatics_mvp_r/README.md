# 智能生物信息学分析平台 - R语言版本

## 🎯 项目概述

智能生物信息学分析平台是一个基于R语言的生物信息学数据分析工具，提供完整的数据预处理、差异表达分析、聚类分析、通路分析和可视化功能。

## 🚀 功能特色

### 核心功能
- **数据预处理**：自动数据清洗、标准化、过滤
- **差异表达分析**：支持DESeq2、edgeR、limma方法
- **聚类分析**：基因聚类、样本聚类
- **通路分析**：KEGG、GO通路富集分析
- **数据可视化**：火山图、热图、散点图、PCA图等
- **Web界面**：基于Shiny的交互式Web界面

### 技术特点
- **R语言开发**：专业的生物信息学分析
- **模块化设计**：易于扩展和维护
- **Web界面**：用户友好的交互界面
- **结果导出**：支持多种格式导出
- **批量处理**：支持批量数据分析

## 📁 项目结构

```
bioinformatics_mvp_r/
├── DESCRIPTION                 # R包描述文件
├── README.md                  # 项目说明文档
├── run_app.R                  # 启动脚本
├── requirements.txt           # Python依赖（如果需要）
├── R/                        # R源代码目录
│   ├── __init__.py           # 包初始化文件
│   ├── main.R                # 主程序入口
│   ├── data_preprocessor.R   # 数据预处理模块
│   ├── analysis_engine.R     # 分析引擎模块
│   ├── visualization_engine.R # 可视化引擎模块
│   ├── web_interface.R       # Web界面模块
│   └── platform.R            # 平台主类
└── app/                      # Shiny Web应用目录
    ├── ui.R                  # 用户界面
    ├── server.R              # 服务器逻辑
    └── help.md               # 帮助文档
```

## 🛠️ 安装和运行

### 1. 安装依赖

```r
# 安装R包
install.packages(c(
  "shiny", "shinydashboard", "DT", "ggplot2", "plotly",
  "pheatmap", "ggpubr", "RColorBrewer", "viridis",
  "data.table", "dplyr", "tidyr"
))

# 安装生物信息学包
if (!require("BiocManager", quietly = TRUE))
    install.packages("BiocManager")

BiocManager::install(c(
  "DESeq2", "edgeR", "limma", "cluster", "factoextra",
  "org.Hs.eg.db", "clusterProfiler", "pathview",
  "enrichplot", "biomaRt", "AnnotationDbi"
))
```

### 2. 启动应用

```bash
# 方法1：使用Rscript
Rscript run_app.R

# 方法2：使用R
R -e "source('run_app.R')"

# 方法3：直接运行R脚本
R < run_app.R
```

### 3. 访问应用

打开浏览器访问：`http://localhost:8080`

## 📊 使用方法

### 1. 数据上传

1. 点击"数据上传"标签
2. 选择数据文件（CSV、Excel、TSV）
3. 选择数据类型（表达数据、甲基化数据、临床数据）
4. 点击"上传数据"按钮

### 2. 数据分析

1. 点击"数据分析"标签
2. 选择分析类型
3. 设置分析参数
4. 点击"开始分析"按钮

### 3. 数据可视化

1. 点击"数据可视化"标签
2. 选择图表类型
3. 设置图表参数
4. 点击"生成图表"按钮

### 4. 结果导出

1. 点击"结果导出"标签
2. 选择要导出的结果
3. 设置输出路径
4. 点击"导出结果"按钮

## 🔧 API使用

### 编程接口

```r
# 创建平台实例
platform <- BioinformaticsPlatform$new()

# 加载数据
data_info <- platform$load_data("data.csv", "expression")

# 执行分析
result <- platform$perform_analysis(
  data_info$data_id, 
  "differential_expression",
  list(p_value_threshold = 0.05, log2fc_threshold = 1.0)
)

# 生成可视化
plot <- platform$generate_visualization(result, "volcano")

# 导出结果
platform$export_results(result$result_id, "./results")
```

### 批量分析

```r
# 批量分析
data_paths <- c("data1.csv", "data2.csv", "data3.csv")
analysis_types <- c("differential_expression", "gene_clustering", "pathway_analysis")
results <- batch_analyze(data_paths, analysis_types)
```

## 📈 分析功能详解

### 差异表达分析

**支持方法**：
- DESeq2：基于负二项分布的模型
- edgeR：基于负二项分布的模型
- limma：基于线性模型的模型

**输出结果**：
- 显著基因列表
- 统计信息（p值、log2FC、校正p值）
- 基因注释信息

### 聚类分析

**支持方法**：
- k-means聚类
- 层次聚类

**距离度量**：
- 欧氏距离
- 相关距离

**输出结果**：
- 聚类结果
- 聚类统计信息
- 聚类可视化

### 通路分析

**支持数据库**：
- KEGG：京都基因与基因组百科全书
- GO：基因本体论

**分析方法**：
- 过度表达分析
- 富集分析
- 基因集分析

**输出结果**：
- 显著通路列表
- 通路统计信息
- 通路可视化

### 可视化图表

**支持图表类型**：
- 火山图：展示差异表达基因
- 热图：展示基因表达模式
- 散点图：展示基因间关系
- 柱状图：展示通路富集结果
- PCA图：展示样本分布
- 聚类树图：展示样本聚类关系

## 🎨 界面说明

### 顶部导航
- **数据上传**：上传数据文件
- **数据分析**：执行各种分析
- **数据可视化**：生成图表
- **结果导出**：导出分析结果
- **使用说明**：查看帮助文档

### 侧边栏
- 显示当前数据文件列表
- 显示分析结果列表
- 快速导航功能

### 主内容区
- 显示当前选中的功能界面
- 提供交互式控件
- 展示分析结果和图表

## 🚀 性能优化

### 内存优化
- 使用`data.table`处理大数据集
- 及时清理不需要的对象
- 使用`gc()`释放内存

### 计算优化
- 并行计算：使用`parallel`包
- 矩阵运算：使用`Matrix`包
- 缓存机制：使用`memoise`包

### 可视化优化
- 使用`plotly`创建交互式图表
- 使用`ggplot2`创建高质量图表
- 使用`gridExtra`组合多个图表

## 📞 技术支持

### 常见问题

**Q: 数据上传失败怎么办？**
A: 检查数据格式是否正确，确保文件格式为CSV、Excel或TSV

**Q: 分析结果为空怎么办？**
A: 检查参数设置，调整阈值设置

**Q: 图表无法显示怎么办？**
A: 检查浏览器设置，确保JavaScript已启用

### 联系方式

如有问题，请联系：
- 邮箱：administrator@openclaw.ai
- 项目地址：https://github.com/openclaw/bioinformatics_platform

## 📄 许可证

本项目采用MIT许可证，详见LICENSE文件。

## 🎯 更新日志

### v1.0.0 (2026-05-13)
- 初始版本发布
- 实现核心功能
- 提供Web界面
- 支持多种分析方法

---

*最后更新：2026-05-13*
*版本：1.0.0*