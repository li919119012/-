@echo off
echo 启动智能生物信息学分析平台...
echo.
echo 访问地址: http://localhost:8080
echo 按 Ctrl+C 停止服务
echo.

Rscript run_app.bat

pause