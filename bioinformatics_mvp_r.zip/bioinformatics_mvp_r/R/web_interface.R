#' Web界面模块
#'
#' @description 提供Shiny Web界面
#' @export
WebInterface <- R6Class("WebInterface",
  public = list(
    #' @description 初始化Web界面
    initialize = function() {
      cat("Web界面初始化完成\n")
    },
    
    #' @description 创建Shiny应用
    #' @param platform 平台实例
    #' @return Shiny应用对象
    create_shiny_app = function(platform) {
      ui <- shiny::fluidPage(
        # 应用标题
        shiny::titlePanel("智能生物信息学分析平台"),
        
        # 导航栏
        shiny::navbarPage(
          "生物信息学分析",
          
          # 数据上传页面
          shiny::tabPanel(
            "数据上传",
            shiny::fluidRow(
              shiny::column(12, 
                shiny::box(
                  title = "数据上传",
                  width = NULL,
                  shiny::fileInput(
                    "data_file", 
                    "选择数据文件:",
                    accept = c(".csv", ".xlsx", ".tsv")
                  ),
                  shiny::selectInput(
                    "data_type", 
                    "数据类型:",
                    choices = c("表达数据", "甲基化数据", "临床数据"),
                    selected = "表达数据"
                  ),
                  shiny::actionButton(
                    "upload_button", 
                    "上传数据",
                    class = "btn-primary"
                  )
                )
              )
            ),
            
            shiny::fluidRow(
              shiny::column(12,
                shiny::box(
                  title = "已上传数据",
                  width = NULL,
                  shiny::tableOutput("data_table")
                )
              )
            )
          ),
          
          # 数据分析页面
          shiny::tabPanel(
            "数据分析",
            shiny::fluidRow(
              shiny::column(4,
                shiny::box(
                  title = "分析设置",
                  width = NULL,
                  shiny::selectInput(
                    "analysis_type",
                    "分析类型:",
                    choices = c(
                      "差异表达分析" = "differential_expression",
                      "基因聚类分析" = "gene_clustering",
                      "样本聚类分析" = "sample_clustering",
                      "通路分析" = "pathway_analysis"
                    ),
                    selected = "differential_expression"
                  ),
                  
                  # 差异表达分析参数
                  shiny::conditionalPanel(
                    condition = "input.analysis_type == 'differential_expression'",
                    shiny::numericInput(
                      "p_value_threshold",
                      "p值阈值:",
                      value = 0.05,
                      min = 0.001,
                      max = 1,
                      step = 0.001
                    ),
                    shiny::numericInput(
                      "log2fc_threshold",
                      "log2FC阈值:",
                      value = 1,
                      min = 0.1,
                      max = 5,
                      step = 0.1
                    ),
                    shiny::selectInput(
                      "analysis_method",
                      "分析方法:",
                      choices = c("DESeq2", "edgeR", "limma"),
                      selected = "DESeq2"
                    )
                  ),
                  
                  # 聚类分析参数
                  shiny::conditionalPanel(
                    condition = "input.analysis_type == 'gene_clustering' || input.analysis_type == 'sample_clustering'",
                    shiny::numericInput(
                      "n_clusters",
                      "聚类数量:",
                      value = 5,
                      min = 2,
                      max = 10,
                      step = 1
                    ),
                    shiny::selectInput(
                      "cluster_method",
                      "聚类方法:",
                      choices = c("kmeans", "层次聚类"),
                      selected = "kmeans"
                    ),
                    shiny::selectInput(
                      "distance_method",
                      "距离方法:",
                      choices = c("欧氏距离", "相关距离"),
                      selected = "欧氏距离"
                    )
                  ),
                  
                  # 通路分析参数
                  shiny::conditionalPanel(
                    condition = "input.analysis_type == 'pathway_analysis'",
                    shiny::numericInput(
                      "pathway_p_value",
                      "p值阈值:",
                      value = 0.05,
                      min = 0.001,
                      max = 1,
                      step = 0.001
                    ),
                    shiny::numericInput(
                      "min_genes",
                      "最少基因数:",
                      value = 5,
                      min = 1,
                      max = 50,
                      step = 1
                    ),
                    shiny::selectInput(
                      "database",
                      "数据库:",
                      choices = c("KEGG", "GO"),
                      selected = "KEGG"
                    )
                  ),
                  
                  shiny::actionButton(
                    "analyze_button",
                    "开始分析",
                    class = "btn-success"
                  )
                )
              ),
              
              shiny::column(8,
                shiny::box(
                  title = "分析结果",
                  width = NULL,
                  shiny::tabsetPanel(
                    shiny::tabPanel(
                      "统计信息",
                      shiny::verbatimTextOutput("analysis_summary")
                    ),
                    shiny::tabPanel(
                      "显著基因",
                      shiny::dataTableOutput("significant_genes")
                    ),
                    shiny::tabPanel(
                      "通路结果",
                      shiny::dataTableOutput("pathway_results")
                    )
                  )
                )
              )
            )
          ),
          
          # 数据可视化页面
          shiny::tabPanel(
            "数据可视化",
            shiny::fluidRow(
              shiny::column(4,
                shiny::box(
                  title = "可视化设置",
                  width = NULL,
                  shiny::selectInput(
                    "plot_type",
                    "图表类型:",
                    choices = c(
                      "火山图" = "volcano",
                      "热图" = "heatmap",
                      "散点图" = "scatter",
                      "柱状图" = "bar",
                      "PCA图" = "pca",
                      "聚类树图" = "dendrogram"
                    ),
                    selected = "volcano"
                  ),
                  
                  # 火山图参数
                  shiny::conditionalPanel(
                    condition = "input.plot_type == 'volcano'",
                    shiny::numericInput(
                      "plot_p_value",
                      "p值阈值:",
                      value = 0.05,
                      min = 0.001,
                      max = 1,
                      step = 0.001
                    ),
                    shiny::numericInput(
                      "plot_log2fc",
                      "log2FC阈值:",
                      value = 1,
                      min = 0.1,
                      max = 5,
                      step = 0.1
                    )
                  ),
                  
                  # 热图参数
                  shiny::conditionalPanel(
                    condition = "input.plot_type == 'heatmap'",
                    shiny::numericInput(
                      "n_genes",
                      "显示基因数:",
                      value = 50,
                      min = 10,
                      max = 200,
                      step = 10
                    ),
                    shiny::selectInput(
                      "color_palette",
                      "颜色方案:",
                      choices = c("RdBu", "PuOr", "BrBG", "PiYG"),
                      selected = "RdBu"
                    )
                  ),
                  
                  # PCA参数
                  shiny::conditionalPanel(
                    condition = "input.plot_type == 'pca'",
                    shiny::selectInput(
                      "pca_group",
                      "分组变量:",
                      choices = c("无分组", "分组1", "分组2"),
                      selected = "无分组"
                    )
                  ),
                  
                  shiny::actionButton(
                    "plot_button",
                    "生成图表",
                    class = "btn-info"
                  )
                )
              ),
              
              shiny::column(8,
                shiny::box(
                  title = "可视化结果",
                  width = NULL,
                  shiny::plotOutput("main_plot", height = "600px")
                )
              )
            )
          ),
          
          # 帮助页面
          shiny::tabPanel(
            "帮助",
            shiny::fluidRow(
              shiny::column(12,
                shiny::box(
                  title = "使用说明",
                  width = NULL,
                  shiny::includeMarkdown("help.md")
                )
              )
            )
          )
        )
      )
      
      server <- function(input, output, session) {
        # 数据存储
        data_store <- reactiveValues()
        results_store <- reactiveValues()
        
        # 数据上传处理
        observeEvent(input$upload_button, {
          req(input$data_file)
          
          file_info <- input$data_file
          file_path <- file_info$datapath
          file_name <- file_info$name
          
          # 根据数据类型选择加载方法
          data_type <- switch(input$data_type,
            "表达数据" = "expression",
            "甲基化数据" = "methylation",
            "临床数据" = "clinical"
          )
          
          # 加载数据
          tryCatch({
            if (data_type == "expression") {
              data <- platform$data_preprocessor$load_expression_data(file_path)
            } else if (data_type == "methylation") {
              data <- platform$data_preprocessor$load_methylation_data(file_path)
            } else if (data_type == "clinical") {
              data <- platform$data_preprocessor$load_clinical_data(file_path)
            }
            
            # 存储数据
            data_store[[file_name]] <- list(
              data = data,
              type = data_type,
              uploaded_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S")
            )
            
            shiny::showNotification("数据上传成功!", type = "success")
            
          }, error = function(e) {
            shiny::showNotification("数据上传失败: ", e$message, type = "error")
          })
        })
        
        # 显示已上传数据
        output$data_table <- shiny::renderDataTable({
          data_info <- data_store[]
          if (length(data_info) > 0) {
            info_df <- data.frame(
              文件名 = names(data_info),
              数据类型 = sapply(data_info, function(x) x$type),
              上传时间 = sapply(data_info, function(x) x$uploaded_at),
              行数 = sapply(data_info, function(x) nrow(x$data)),
              列数 = sapply(data_info, function(x) ncol(x$data)),
              stringsAsFactors = FALSE
            )
            return(info_df)
          } else {
            return(data.frame())
          }
        })
        
        # 数据分析处理
        observeEvent(input$analyze_button, {
          req(input$data_file)
          
          file_name <- input$data_file$name
          if (!file_name %in% names(data_store)) {
            shiny::showNotification("请先上传数据!", type = "warning")
            return()
          }
          
          # 获取数据
          data <- data_store[[file_name]]$data
          
          # 设置分析参数
          params <- list()
          
          if (input$analysis_type == "differential_expression") {
            params <- list(
              p_value_threshold = input$p_value_threshold,
              log2fc_threshold = input$log2fc_threshold,
              method = input$analysis_method
            )
          } else if (input$analysis_type == "gene_clustering" || input$analysis_type == "sample_clustering") {
            params <- list(
              n_clusters = input$n_clusters,
              method = switch(input$cluster_method,
                "kmeans" = "kmeans",
                "层次聚类" = "hierarchical"
              ),
              distance_method = switch(input$distance_method,
                "欧氏距离" = "euclidean",
                "相关距离" = "correlation"
              )
            )
          } else if (input$analysis_type == "pathway_analysis") {
            params <- list(
              p_value_threshold = input$pathway_p_value,
              min_genes = input$min_genes,
              database = input$database
            )
          }
          
          # 执行分析
          tryCatch({
            result <- platform$analysis_engine[[paste0(input$analysis_type, "_analysis")]](data, params)
            
            # 存储结果
            result_id <- paste0(input$analysis_type, "_", format(Sys.time(), "%Y%m%d_%H%M%S"))
            results_store[[result_id]] <- result
            
            shiny::showNotification("分析完成!", type = "success")
            
          }, error = function(e) {
            shiny::showNotification("分析失败: ", e$message, type = "error")
          })
        })
        
        # 显示分析结果
        output$analysis_summary <- shiny::renderPrint({
          if (length(results_store) > 0) {
            # 获取最新结果
            result_id <- names(results_store)[length(results_store)]
            result <- results_store[[result_id]]
            
            if ("summary" %in% names(result)) {
              cat("分析结果摘要:\n")
              print(result$summary)
            } else {
              cat("分析结果:\n")
              print(result)
            }
          } else {
            cat("暂无分析结果\n")
          }
        })
        
        # 显示显著基因
        output$significant_genes <- shiny::renderDataTable({
          if (length(results_store) > 0) {
            result_id <- names(results_store)[length(results_store)]
            result <- results_store[[result_id]]
            
            if ("significant_genes" %in% names(result)) {
              return(result$significant_genes)
            } else {
              return(data.frame())
            }
          } else {
            return(data.frame())
          }
        })
        
        # 显示通路结果
        output$pathway_results <- shiny::renderDataTable({
          if (length(results_store) > 0) {
            result_id <- names(results_store)[length(results_store)]
            result <- results_store[[result_id]]
            
            if ("significant_pathways" %in% names(result)) {
              return(result$significant_pathways)
            } else {
              return(data.frame())
            }
          } else {
            return(data.frame())
          }
        })
        
        # 生成图表
        observeEvent(input$plot_button, {
          req(length(results_store) > 0)
          
          result_id <- names(results_store)[length(results_store)]
          result <- results_store[[result_id]]
          
          # 根据图表类型生成图表
          plot <- NULL
          
          if (input$plot_type == "volcano") {
            plot_params <- list(
              p_value_threshold = input$plot_p_value,
              log2fc_threshold = input$plot_log2fc
            )
            plot <- platform$visualization_engine$create_volcano_plot(result, plot_params)
          } else if (input$plot_type == "heatmap") {
            plot_params <- list(
              n_genes = input$n_genes,
              color_palette = input$color_palette
            )
            plot <- platform$visualization_engine$create_heatmap(result, plot_params)
          } else if (input$plot_type == "scatter") {
            plot <- platform$visualization_engine$create_scatter_plot(result)
          } else if (input$plot_type == "bar") {
            plot <- platform$visualization_engine$create_bar_plot(result)
          } else if (input$plot_type == "pca") {
            # 获取原始数据
            if (length(data_store) > 0) {
              data_names <- names(data_store)
              data <- data_store[[data_names[1]]]$data
              plot_params <- list(
                group_var = input$pca_group
              )
              plot <- platform$visualization_engine$create_pca_plot(data, plot_params)
            }
          } else if (input$plot_type == "dendrogram") {
            plot <- platform$visualization_engine$create_dendrogram(result)
          }
          
          # 显示图表
          output$main_plot <- shiny::renderPlot({
            if (!is.null(plot)) {
              print(plot)
            } else {
              shiny::plotOutput(NULL)
            }
          })
          
          if (!is.null(plot)) {
            shiny::showNotification("图表生成成功!", type = "success")
          } else {
            shiny::showNotification("图表生成失败!", type = "error")
          }
        })
      }
      
      shiny::shinyApp(ui = ui, server = server)
    }
  )
)