#' 数据预处理模块
#'
#' @description 提供生物信息学数据的加载和预处理功能
#' @export
DataPreprocessor <- R6Class("DataPreprocessor",
  public = list(
    #' @description 初始化数据预处理器
    initialize = function() {
      self$supported_formats <- c(".csv", ".xlsx", ".tsv", ".txt")
      self$gene_id_columns <- c("gene_id", "gene", "ensembl", "symbol")
      self$sample_id_columns <- c("sample_id", "sample", "patient_id", "id")
      cat("数据预处理器初始化完成\n")
    },
    
    #' @description 加载基因表达数据
    #' @param file_path 数据文件路径
    #' @return 处理后的表达数据
    load_expression_data = function(file_path) {
      cat("加载表达数据:", file_path, "\n")
      
      # 检查文件是否存在
      if (!file.exists(file_path)) {
        stop("文件不存在: ", file_path)
      }
      
      # 检查文件格式
      file_ext <- tools::file_ext(file_path)
      
      # 根据格式加载数据
      if (file_ext == "csv") {
        data <- read.csv(file_path, row.names = 1, check.names = FALSE)
      } else if (file_ext == "xlsx") {
        data <- openxlsx::read.xlsx(file_path, rowNames = TRUE)
      } else if (file_ext == "tsv") {
        data <- read.delim(file_path, row.names = 1, check.names = FALSE)
      } else {
        data <- read.delim(file_path, row.names = 1, check.names = FALSE)
      }
      
      # 数据预处理
      data <- self$preprocess_expression_data(data)
      
      cat("数据加载完成:", dim(data), "\n")
      return(data)
    },
    
    #' @description 加载甲基化数据
    #' @param file_path 数据文件路径
    #' @return 处理后的甲基化数据
    load_methylation_data = function(file_path) {
      cat("加载甲基化数据:", file_path, "\n")
      
      # 加载数据
      data <- read.csv(file_path, row.names = 1, check.names = FALSE)
      
      # 数据预处理
      data <- self$preprocess_methylation_data(data)
      
      cat("数据加载完成:", dim(data), "\n")
      return(data)
    },
    
    #' @description 加载临床数据
    #' @param file_path 数据文件路径
    #' @return 处理后的临床数据
    load_clinical_data = function(file_path) {
      cat("加载临床数据:", file_path, "\n")
      
      # 加载数据
      data <- read.csv(file_path, check.names = FALSE)
      
      # 数据预处理
      data <- self$preprocess_clinical_data(data)
      
      cat("数据加载完成:", dim(data), "\n")
      return(data)
    },
    
    #' @description 预处理表达数据
    #' @param data 原始表达数据
    #' @return 预处理后的表达数据
    preprocess_expression_data = function(data) {
      # 转换数据类型
      numeric_cols <- sapply(data, is.numeric)
      data[, numeric_cols] <- as.data.frame(lapply(data[, numeric_cols], as.numeric))
      
      # 处理缺失值
      data <- self$handle_missing_values(data)
      
      # 过滤低表达基因
      data <- self$filter_low_expression_genes(data)
      
      return(data)
    },
    
    #' @description 预处理甲基化数据
    #' @param data 原始甲基化数据
    #' @return 预处理后的甲基化数据
    preprocess_methylation_data = function(data) {
      # 转换数据类型
      numeric_cols <- sapply(data, is.numeric)
      data[, numeric_cols] <- as.data.frame(lapply(data[, numeric_cols], as.numeric))
      
      # 处理缺失值
      data <- self$handle_missing_values(data)
      
      # 过滤低覆盖位点
      data <- self$filter_low_coverage_sites(data)
      
      return(data)
    },
    
    #' @description 预处理临床数据
    #' @param data 原始临床数据
    #' @return 预处理后的临床数据
    preprocess_clinical_data = function(data) {
      # 处理分类变量
      for (col in names(data)) {
        if (!is.numeric(data[[col]])) {
          data[[col]] <- as.factor(data[[col]])
        }
      }
      
      # 处理缺失值
      data <- self$handle_missing_values(data)
      
      # 标准化变量名
      names(data) <- tolower(gsub(" ", "_", names(data)))
      
      return(data)
    },
    
    #' @description 处理缺失值
    #' @param data 原始数据
    #' @return 处理后的数据
    handle_missing_values = function(data) {
      # 对于数值型数据，用中位数填充
      for (col in names(data)) {
        if (is.numeric(data[[col]])) {
          if (any(is.na(data[[col]]))) {
            median_val <- median(data[[col]], na.rm = TRUE)
            data[[col]][is.na(data[[col]])] <- median_val
          }
        } else {
          # 对于分类数据，用众数填充
          if (any(is.na(data[[col]]))) {
            mode_val <- names(sort(table(data[[col]]), decreasing = TRUE))[1]
            data[[col]][is.na(data[[col]])] <- mode_val
          }
        }
      }
      
      return(data)
    },
    
    #' @description 过滤低表达基因
    #' @param data 表达数据
    #' @param threshold 表达阈值
    #' @return 过滤后的数据
    filter_low_expression_genes = function(data, threshold = 1.0) {
      # 计算每个基因的平均表达量
      mean_expression <- rowMeans(data, na.rm = TRUE)
      
      # 过滤低表达基因
      filtered_data <- data[mean_expression >= threshold, ]
      
      cat("过滤低表达基因:", dim(data)[1], "->", dim(filtered_data)[1], "\n")
      
      return(filtered_data)
    },
    
    #' @description 过滤低覆盖位点
    #' @param data 甲基化数据
    #' @param threshold 覆盖阈值
    #' @return 过滤后的数据
    filter_low_coverage_sites = function(data, threshold = 0.8) {
      # 计算每个位点的覆盖度
      coverage <- rowSums(!is.na(data)) / ncol(data)
      
      # 过滤低覆盖位点
      filtered_data <- data[coverage >= threshold, ]
      
      cat("过滤低覆盖位点:", dim(data)[1], "->", dim(filtered_data)[1], "\n")
      
      return(filtered_data)
    },
    
    #' @description 获取数据摘要
    #' @param data 数据
    #' @return 数据摘要
    get_data_summary = function(data) {
      summary <- list(
        shape = dim(data),
        columns = names(data),
        row_names = rownames(data),
        data_types = sapply(data, class),
        missing_values = sapply(data, function(x) sum(is.na(x))),
        memory_usage = object.size(data)
      )
      
      # 添加数值列的统计信息
      numeric_cols <- sapply(data, is.numeric)
      if (any(numeric_cols)) {
        summary$numeric_stats <- summary(data[, numeric_cols, drop = FALSE])
      }
      
      return(summary)
    }
  )
)