#' 可视化引擎模块
#'
#' @description 提供生物信息学数据可视化功能
#' @export
VisualizationEngine <- R6Class("VisualizationEngine",
  public = list(
    #' @description 初始化可视化引擎
    initialize = function() {
      cat("可视化引擎初始化完成\n")
    },
    
    #' @description 创建火山图
    #' @param data 分析结果数据
    #' @param params 图表参数
    #' @return 火山图对象
    create_volcano_plot = function(data, params = list()) {
      cat("创建火山图...\n")
      
      # 设置默认参数
      default_params <- list(
        p_value_threshold = 0.05,
        log2fc_threshold = 1.0,
        point_size = 3,
        title = "火山图",
        xlab = "log2 Fold Change",
        ylab = "-log10(p-value)",
        color_up = "#E74C3C",
        color_down = "#3498DB",
        color_not = "#95A5A6"
      )
      
      params <- modifyList(default_params, params)
      
      tryCatch({
        # 准备数据
        if (is.list(data) && "significant_genes" %in% names(data)) {
          plot_data <- data$significant_genes
        } else if (is.data.frame(data)) {
          plot_data <- data
        } else {
          stop("不支持的数据格式")
        }
        
        # 添加颜色列
        plot_data$color <- ifelse(
          plot_data$log2FoldChange > params$log2fc_threshold,
          params$color_up,
          ifelse(
            plot_data$log2FoldChange < -params$log2fc_threshold,
            params$color_down,
            params$color_not
          )
        )
        
        # 创建火山图
        p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = log2FoldChange, y = -log10(pvalue))) +
          ggplot2::geom_point(ggplot2::aes(color = color), size = params$point_size, alpha = 0.7) +
          ggplot2::scale_color_manual(values = c(params$color_up, params$color_down, params$color_not)) +
          ggplot2::geom_hline(yintercept = -log10(params$p_value_threshold), linetype = "dashed", color = "red") +
          ggplot2::geom_vline(xintercept = params$log2fc_threshold, linetype = "dashed", color = "red") +
          ggplot2::geom_vline(xintercept = -params$log2fc_threshold, linetype = "dashed", color = "red") +
          ggplot2::labs(
            title = params$title,
            x = params$xlab,
            y = params$ylab,
            color = "显著性"
          ) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.title = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold"),
            axis.title = ggplot2::element_text(size = 12),
            legend.position = "right"
          )
        
        cat("火山图创建完成\n")
        return(p)
        
      }, error = function(e) {
        cat("火山图创建失败:", e$message, "\n")
        return(NULL)
      })
    },
    
    #' @description 创建热图
    #' @param data 分析结果数据
    #' @param params 图表参数
    #' @return 热图对象
    create_heatmap = function(data, params = list()) {
      cat("创建热图...\n")
      
      # 设置默认参数
      default_params <- list(
        n_genes = 50,
        cluster_rows = TRUE,
        cluster_cols = TRUE,
        scale = "row",
        color_palette = "RdBu",
        title = "热图",
        show_rownames = FALSE,
        show_colnames = FALSE,
        treeheight_row = 0.2,
        treeheight_col = 0.2
      )
      
      params <- modifyList(default_params, params)
      
      tryCatch({
        # 准备数据
        if (is.list(data) && "significant_genes" %in% names(data)) {
          plot_data <- data$significant_genes[, 1:min(ncol(data), 10)]
        } else if (is.matrix(data) || is.data.frame(data)) {
          plot_data <- data
        } else {
          stop("不支持的数据格式")
        }
        
        # 取前N个基因
        if (nrow(plot_data) > params$n_genes) {
          plot_data <- plot_data[1:params$n_genes, ]
        }
        
        # 创建热图
        p <- pheatmap::pheatmap(
          plot_data,
          scale = params$scale,
          clustering_distance_rows = "euclidean",
          clustering_distance_cols = "euclidean",
          clustering_method = "ward.D2",
          show_rownames = params$show_rownames,
          show_colnames = params$show_colnames,
          treeheight_row = params$treeheight_row,
          treeheight_col = params$treeheight_col,
          color = RColorBrewer::brewer.pal(11, params$color_palette),
          main = params$title,
          fontsize = 8,
          fontsize_row = 6,
          fontsize_col = 6
        )
        
        cat("热图创建完成\n")
        return(p)
        
      }, error = function(e) {
        cat("热图创建失败:", e$message, "\n")
        return(NULL)
      })
    },
    
    #' @description 创建散点图
    #' @param data 分析结果数据
    #' @param params 图表参数
    #' @return 散点图对象
    create_scatter_plot = function(data, params = list()) {
      cat("创建散点图...\n")
      
      # 设置默认参数
      default_params <- list(
        x_var = "log2FoldChange",
        y_var = "pvalue",
        point_size = 3,
        alpha = 0.7,
        title = "散点图",
        xlab = "log2 Fold Change",
        ylab = "p-value",
        color_var = NULL,
        shape_var = NULL
      )
      
      params <- modifyList(default_params, params)
      
      tryCatch({
        # 准备数据
        if (is.list(data) && "significant_genes" %in% names(data)) {
          plot_data <- data$significant_genes
        } else if (is.data.frame(data)) {
          plot_data <- data
        } else {
          stop("不支持的数据格式")
        }
        
        # 创建散点图
        p <- ggplot2::ggplot(plot_data, ggplot2::aes_string(x = params$x_var, y = params$y_var)) +
          ggplot2::geom_point(size = params$point_size, alpha = params$alpha)
        
        # 添加颜色映射
        if (!is.null(params$color_var)) {
          p <- p + ggplot2::aes_string(color = params$color_var) +
            ggplot2::scale_color_brewer(palette = "Set1")
        }
        
        # 添加形状映射
        if (!is.null(params$shape_var)) {
          p <- p + ggplot2::aes_string(shape = params$shape_var)
        }
        
        # 添加标签
        p <- p + ggplot2::labs(
          title = params$title,
          x = params$xlab,
          y = params$ylab
        ) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.title = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold")
          )
        
        cat("散点图创建完成\n")
        return(p)
        
      }, error = function(e) {
        cat("散点图创建失败:", e$message, "\n")
        return(NULL)
      })
    },
    
    #' @description 创建柱状图
    #' @param data 分析结果数据
    #' @param params 图表参数
    #' @return 柱状图对象
    create_bar_plot = function(data, params = list()) {
      cat("创建柱状图...\n")
      
      # 设置默认参数
      default_params <- list(
        n_items = 20,
        x_var = "Description",
        y_var = "pvalue",
        color_var = NULL,
        title = "柱状图",
        xlab = "项目",
        ylab = "p-value",
        orientation = "vertical"
      )
      
      params <- modifyList(default_params, params)
      
      tryCatch({
        # 准备数据
        if (is.list(data) && "significant_pathways" %in% names(data)) {
          plot_data <- data$significant_pathways
        } else if (is.data.frame(data)) {
          plot_data <- data
        } else {
          stop("不支持的数据格式")
        }
        
        # 取前N个项目
        if (nrow(plot_data) > params$n_items) {
          plot_data <- plot_data[1:params$n_items, ]
        }
        
        # 转换p值为负对数
        if (params$y_var == "pvalue") {
          plot_data$neg_log10_pvalue <- -log10(plot_data$pvalue)
          params$y_var <- "neg_log10_pvalue"
          params$ylab <- "-log10(p-value)"
        }
        
        # 创建柱状图
        if (params$orientation == "vertical") {
          p <- ggplot2::ggplot(plot_data, ggplot2::aes_string(x = params$x_var, y = params$y_var)) +
            ggplot2::geom_col(ggplot2::aes(fill = params$color_var), width = 0.8) +
            ggplot2::coord_flip() +
            ggplot2::labs(
              title = params$title,
              x = params$xlab,
              y = params$ylab,
              fill = params$color_var
            )
        } else {
          p <- ggplot2::ggplot(plot_data, ggplot2::aes_string(x = params$x_var, y = params$y_var)) +
            ggplot2::geom_col(ggplot2::aes(fill = params$color_var), width = 0.8) +
            ggplot2::labs(
              title = params$title,
              x = params$xlab,
              y = params$ylab,
              fill = params$color_var
            )
        }
        
        p <- p + ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.title = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold"),
            axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
            legend.position = "right"
          )
        
        cat("柱状图创建完成\n")
        return(p)
        
      }, error = function(e) {
        cat("柱状图创建失败:", e$message, "\n")
        return(NULL)
      })
    },
    
    #' @description 创建PCA图
    #' @param data 表达数据
    #' @param params 图表参数
    #' @return PCA图对象
    create_pca_plot = function(data, params = list()) {
      cat("创建PCA图...\n")
      
      # 设置默认参数
      default_params <- list(
        n_components = 2,
        group_var = NULL,
        title = "PCA图",
        xlab = "PC1",
        ylab = "PC2",
        point_size = 3,
        alpha = 0.7,
        color_palette = "Set1"
      )
      
      params <- modifyList(default_params, params)
      
      tryCatch({
        # 数据标准化
        scaled_data <- scale(data)
        
        # 执行PCA
        pca_result <- prcomp(scaled_data, center = TRUE, scale. = TRUE)
        
        # 提取主成分
        pca_scores <- as.data.frame(pca_result$x[, 1:params$n_components])
        colnames(pca_scores) <- c(params$xlab, params$ylab)
        
        # 添加分组信息
        if (!is.null(params$group_var)) {
          pca_scores$group <- params$group_var
        }
        
        # 创建PCA图
        p <- ggplot2::ggplot(pca_scores, ggplot2::aes_string(x = params$xlab, y = params$ylab)) +
          ggplot2::geom_point(size = params$point_size, alpha = params$alpha)
        
        if (!is.null(params$group_var)) {
          p <- p + ggplot2::aes_string(color = "group") +
            ggplot2::scale_color_brewer(palette = params$color_palette)
        }
        
        p <- p + ggplot2::labs(
          title = params$title,
          x = params$xlab,
          y = params$ylab
        ) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.title = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold")
          )
        
        # 添加解释方差
        explained_var <- round(pca_result$sdev^2 / sum(pca_result$sdev^2) * 100, 1)
        p <- p + ggplot2::annotate(
          "text", 
          x = max(pca_scores[[params$xlab]]) * 0.8, 
          y = max(pca_scores[[params$ylab]]) * 0.9,
          label = paste0("PC1: ", explained_var[1], "%, PC2: ", explained_var[2], "%"),
          size = 4
        )
        
        cat("PCA图创建完成\n")
        return(p)
        
      }, error = function(e) {
        cat("PCA图创建失败:", e$message, "\n")
        return(NULL)
      })
    },
    
    #' @description 创建聚类树图
    #' @param data 分析结果数据
    #' @param params 图表参数
    #' @return 聚类树图对象
    create_dendrogram = function(data, params = list()) {
      cat("创建聚类树图...\n")
      
      # 设置默认参数
      default_params <- list(
        method = "ward.D2",
        distance_method = "euclidean",
        title = "聚类树图",
        leaf_labels = TRUE,
        leaf_size = 3
      )
      
      params <- modifyList(default_params, params)
      
      tryCatch({
        # 准备数据
        if (is.list(data) && "dendrogram" %in% names(data)) {
          hc <- data$dendrogram
        } else {
          # 计算距离矩阵
          if (params$distance_method == "euclidean") {
            dist_matrix <- dist(data, method = "euclidean")
          } else if (params$distance_method == "correlation") {
            dist_matrix <- as.dist(1 - cor(t(data)))
          } else {
            stop("不支持的距离方法: ", params$distance_method)
          }
          
          # 执行层次聚类
          hc <- hclust(dist_matrix, method = params$method)
        }
        
        # 创建聚类树图
        p <- ggplot2::ggplot(as.data.frame(hc$height), ggplot2::aes(x = seq_along(hc$height), y = hc$height)) +
          ggplot2::geom_line() +
          ggplot2::labs(
            title = params$title,
            x = "样本",
            y = "距离"
          ) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.title = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold")
          )
        
        cat("聚类树图创建完成\n")
        return(p)
        
      }, error = function(e) {
        cat("聚类树图创建失败:", e$message, "\n")
        return(NULL)
      })
    }
  )
)