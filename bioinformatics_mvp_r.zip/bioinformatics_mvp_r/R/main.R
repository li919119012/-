#' 主应用程序入口
#'
#' @description 智能生物信息学分析平台的主应用程序
#' @export
#' @examples
#' # 启动Web应用
#' # main()

main <- function() {
  cat("智能生物信息学分析平台 - MVP版本\n")
  cat("=" %R% 50 %R% "\n")
  
  # 创建平台实例
  platform <- BioinformaticsPlatform$new()
  
  # 启动Web应用
  cat("启动Web服务: http://localhost:8080\n")
  cat("按 Ctrl+C 停止服务\n")
  
  # 启动Shiny应用
  shiny::runApp(
    appDir = system.file("app", package = "bioinformatics_platform"),
    host = "0.0.0.0",
    port = 8080,
    launch.browser = TRUE
  )
}

#' 创建平台实例
#'
#' @description 创建生物信息学分析平台实例
#' @return 平台实例对象
#' @export
create_platform <- function() {
  BioinformaticsPlatform$new()
}

#' 数据分析入口函数
#'
#' @param data_path 数据文件路径
#' @param analysis_type 分析类型 ("differential_expression", "clustering", "pathway")
#' @param params 分析参数列表
#' @return 分析结果列表
#' @export
analyze_data <- function(data_path, analysis_type = "differential_expression", params = list()) {
  platform <- create_platform()
  
  # 加载数据
  data_info <- platform$load_data(data_path)
  
  if (data_info$status != "success") {
    stop("数据加载失败: ", data_info$error)
  }
  
  # 执行分析
  result <- platform$perform_analysis(data_info$data_id, analysis_type, params)
  
  if (result$status != "success") {
    stop("分析失败: ", result$error)
  }
  
  return(result$results)
}

#' 生成可视化图表
#'
#' @param result 分析结果
#' @param plot_type 图表类型 ("volcano", "heatmap", "scatter", "bar")
#' @return 图表对象
#' @export
generate_plot <- function(result, plot_type = "volcano") {
  platform <- create_platform()
  
  # 生成图表
  plot_data <- platform$generate_visualization(result, plot_type)
  
  if (plot_data$status != "success") {
    stop("图表生成失败: ", plot_data$error)
  }
  
  return(plot_data$plot)
}

#' 批量分析函数
#'
#' @param data_paths 数据文件路径列表
#' @param analysis_types 分析类型列表
#' @param params 分析参数列表
#' @return 批量分析结果
#' @export
batch_analyze <- function(data_paths, analysis_types, params = list()) {
  results <- list()
  
  for (i in seq_along(data_paths)) {
    data_path <- data_paths[i]
    analysis_type <- analysis_types[i]
    
    cat("正在分析文件: ", data_path, "\n")
    
    tryCatch({
      result <- analyze_data(data_path, analysis_type, params)
      results[[data_path]] <- result
      cat("分析完成: ", data_path, "\n")
    }, error = function(e) {
      cat("分析失败: ", data_path, " - ", e$message, "\n")
      results[[data_path]] <- list(error = e$message)
    })
  }
  
  return(results)
}