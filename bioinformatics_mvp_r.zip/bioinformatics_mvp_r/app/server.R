#' Shiny Web界面 - Server部分
#'
#' @description 生物信息学分析平台的Web界面Server逻辑
#' @export

library(shiny)
library(shinydashboard)
library(shinyjs)
library(DT)
library(ggplot2)
library(plotly)

# 定义Server逻辑
server <- function(input, output, session) {
  
  # 数据存储
  data_store <- reactiveValues()
  results_store <- reactiveValues()
  current_data_id <- reactiveValues()
  
  # 初始化
  observe({
    # 创建示例数据
    cat("初始化示例数据...\n")
    
    # 创建示例表达数据
    set.seed(123)
    genes <- paste0("Gene", 1:1000)
    samples <- paste0("Sample", 1:20)
    expression_data <- matrix(rnbinom(1000 * 20, mu = 50, size = 10), nrow = 1000, ncol = 20)
    rownames(expression_data) <- genes
    colnames(expression_data) <- samples
    
    # 添加分组信息
    group_info <- rep(c("A", "B"), each = 10)
    names(group_info) <- samples
    
    # 创建数据对象
    data_obj <- list(
      expression_data = expression_data,
      group_info = group_info,
      clinical_data = data.frame(
        sample_id = samples,
        age = rnorm(20, mean = 50, sd = 10),
        gender = sample(c("M", "F"), 20, replace = TRUE),
        diagnosis = sample(c("Normal", "Disease"), 20, replace = TRUE),
        stringsAsFactors = FALSE
      )
    )
    
    # 存储数据
    data_store$example_data <- data_obj
    current_data_id$data_id <- "example_data"
    
    # 创建示例分析结果
    results_store$example_result <- list(
      significant_genes = data.frame(
        gene_id = genes[1:50],
        gene_symbol = paste0("Symbol", 1:50),
        log2FoldChange = rnorm(50, mean = 2, sd = 1),
        pvalue = runif(50, min = 1e-10, max = 0.01),
        padj = p.adjust(runif(50, min = 1e-10, max = 0.01), method = "BH"),
        stringsAsFactors = FALSE
      ),
      significant_pathways = data.frame(
        ID = paste0("Pathway", 1:20),
        Description = paste0("Pathway Description", 1:20),
        pvalue = runif(20, min = 1e-10, max = 0.01),
        padj = p.adjust(runif(20, min = 1e-10, max = 0.01), method = "BH"),
        GeneRatio = runif(20, min = 0.1, max = 0.8),
        BgRatio = runif(20, min = 0.01, max = 0.1),
        Count = sample(5:50, 20, replace = TRUE),
        stringsAsFactors = FALSE
      ),
      summary = list(
        total_genes = 1000,
        significant_genes = 50,
        total_pathways = 20,
        significant_pathways = 20,
        analysis_type = "differential_expression"
      )
    )
    
    cat("初始化完成!\n")
  })
  
  # 数据上传处理
  observeEvent(input$upload_button, {
    req(input$data_file)
    
    # 显示加载状态
    showNotification("正在上传数据...", duration = 2, type = "message")
    
    file_info <- input$data_file
    file_path <- file_info$datapath
    file_name <- file_info$name
    
    # 模拟上传过程
    Sys.sleep(1)
    
    # 创建模拟数据
    set.seed(123)
    genes <- paste0("Gene", 1:500)
    samples <- paste0("Sample", 1:10)
    expression_data <- matrix(rnbinom(500 * 10, mu = 30, size = 8), nrow = 500, ncol = 10)
    rownames(expression_data) <- genes
    colnames(expression_data) <- samples
    
    data_obj <- list(
      expression_data = expression_data,
      group_info = rep(c("A", "B"), each = 5),
      clinical_data = data.frame(
        sample_id = samples,
        age = rnorm(10, mean = 45, sd = 8),
        gender = sample(c("M", "F"), 10, replace = TRUE),
        diagnosis = sample(c("Normal", "Disease"), 10, replace = TRUE),
        stringsAsFactors = FALSE
      )
    )
    
    # 存储数据
    data_store[[file_name]] <- data_obj
    current_data_id$data_id <- file_name
    
    showNotification("数据上传成功!", duration = 3, type = "success")
  })
  
  # 显示已上传数据
  output$data_table <- DT::renderDT({
    data_info <- data_store[]
    if (length(data_info) > 0) {
      info_df <- data.frame(
        文件名 = names(data_info),
        数据类型 = sapply(data_info, function(x) "表达数据"),
        上传时间 = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
        行数 = sapply(data_info, function(x) nrow(x$expression_data)),
        列数 = sapply(data_info, function(x) ncol(x$expression_data)),
        操作 = sapply(names(data_info), function(name) {
          tags$a(
            href = "#",
            class = "btn btn-primary btn-xs",
            onclick = paste0("selectData('", name, "')"),
            "选择"
          )
        }),
        stringsAsFactors = FALSE
      )
      
      DT::datatable(
        info_df,
        options = list(
          pageLength = 10,
          lengthMenu = c(5, 10, 20),
          language = list(
            url = '//cdn.datatables.net/plug-ins/1.10.11/i18n/Chinese.json'
          )
        ),
        rownames = FALSE
      )
    } else {
      DT::datatable(data.frame())
    }
  })
  
  # 选择数据
  observe({
    if (!is.null(input$data_table_rows_selected)) {
      selected_rows <- input$data_table_rows_selected
      if (length(selected_rows) > 0) {
        selected_name <- names(data_store)[selected_rows[1]]
        current_data_id$data_id <- selected_name
      }
    }
  })
  
  # 数据分析处理
  observeEvent(input$analyze_button, {
    req(current_data_id$data_id)
    
    data_id <- current_data_id$data_id
    data_obj <- data_store[[data_id]]
    
    # 显示加载状态
    showNotification("正在分析数据...", duration = 2, type = "message")
    
    # 模拟分析过程
    Sys.sleep(3)
    
    # 根据分析类型生成结果
    analysis_type <- input$analysis_type
    
    if (analysis_type == "differential_expression") {
      # 差异表达分析结果
      set.seed(123)
      genes <- rownames(data_obj$expression_data)
      result <- list(
        significant_genes = data.frame(
          gene_id = genes[1:100],
          gene_symbol = paste0("Symbol", 1:100),
          log2FoldChange = rnorm(100, mean = 1.5, sd = 0.8),
          pvalue = runif(100, min = 1e-15, max = 0.001),
          padj = p.adjust(runif(100, min = 1e-15, max = 0.001), method = "BH"),
          stringsAsFactors = FALSE
        ),
        summary = list(
          total_genes = length(genes),
          significant_genes = 100,
          p_value_threshold = input$p_value_threshold,
          log2fc_threshold = input$log2fc_threshold,
          method = input$analysis_method
        )
      )
    } else if (analysis_type == "gene_clustering") {
      # 基因聚类分析结果
      set.seed(123)
      result <- list(
        clusters = list(
          cluster = sample(1:input$n_clusters, length(rownames(data_obj$expression_data)), replace = TRUE),
          size = table(sample(1:input$n_clusters, 1000, replace = TRUE)),
          centers = matrix(rnorm(input$n_clusters * 10, mean = 0, sd = 1), nrow = input$n_clusters, ncol = 10)
        ),
        summary = list(
          n_clusters = input$n_clusters,
          method = input$cluster_method,
          distance_method = input$distance_method,
          total_genes = length(rownames(data_obj$expression_data))
        )
      )
    } else if (analysis_type == "sample_clustering") {
      # 样本聚类分析结果
      set.seed(123)
      result <- list(
        clusters = list(
          cluster = sample(1:input$n_clusters, length(colnames(data_obj$expression_data)), replace = TRUE),
          size = table(sample(1:input$n_clusters, 20, replace = TRUE)),
          centers = matrix(rnorm(input$n_clusters * 10, mean = 0, sd = 1), nrow = input$n_clusters, ncol = 10)
        ),
        summary = list(
          n_clusters = input$n_clusters,
          method = input$cluster_method,
          distance_method = input$distance_method,
          total_samples = length(colnames(data_obj$expression_data))
        )
      )
    } else if (analysis_type == "pathway_analysis") {
      # 通路分析结果
      set.seed(123)
      result <- list(
        significant_pathways = data.frame(
          ID = paste0("Pathway", 1:30),
          Description = paste0("Pathway Description", 1:30),
          pvalue = runif(30, min = 1e-12, max = 0.01),
          padj = p.adjust(runif(30, min = 1e-12, max = 0.01), method = "BH"),
          GeneRatio = runif(30, min = 0.05, max = 0.6),
          BgRatio = runif(30, min = 0.01, max = 0.08),
          Count = sample(3:40, 30, replace = TRUE),
          stringsAsFactors = FALSE
        ),
        summary = list(
          total_pathways = 50,
          significant_pathways = 30,
          p_value_threshold = input$pathway_p_value,
          min_genes = input$min_genes,
          database = input$database
        )
      )
    }
    
    # 存储结果
    result_id <- paste0(analysis_type, "_", format(Sys.time(), "%Y%m%d_%H%M%S"))
    results_store[[result_id]] <- result
    
    showNotification("分析完成!", duration = 3, type = "success")
  })
  
  # 显示分析结果
  output$analysis_summary <- renderPrint({
    if (length(results_store) > 0) {
      result_id <- names(results_store)[length(results_store)]
      result <- results_store[[result_id]]
      
      cat("分析结果摘要:\n")
      cat("=============\n")
      cat("分析类型:", result_id, "\n")
      cat("创建时间:", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")
      cat("\n")
      
      if ("summary" %in% names(result)) {
        print(result$summary)
      }
    } else {
      cat("暂无分析结果\n")
    }
  })
  
  # 显示显著基因
  output$significant_genes <- DT::renderDT({
    if (length(results_store) > 0) {
      result_id <- names(results_store)[length(results_store)]
      result <- results_store[[result_id]]
      
      if ("significant_genes" %in% names(result)) {
        DT::datatable(
          result$significant_genes,
          options = list(
            pageLength = 10,
            lengthMenu = c(5, 10, 20),
            language = list(
              url = '//cdn.datatables.net/plug-ins/1.10.11/i18n/Chinese.json'
            )
          ),
          rownames = FALSE
        )
      } else {
        DT::datatable(data.frame())
      }
    } else {
      DT::datatable(data.frame())
    }
  })
  
  # 显示通路结果
  output$pathway_results <- DT::renderDT({
    if (length(results_store) > 0) {
      result_id <- names(results_store)[length(results_store)]
      result <- results_store[[result_id]]
      
      if ("significant_pathways" %in% names(result)) {
        DT::datatable(
          result$significant_pathways,
          options = list(
            pageLength = 10,
            lengthMenu = c(5, 10, 20),
            language = list(
              url = '//cdn.datatables.net/plug-ins/1.10.11/i18n/Chinese.json'
            )
          ),
          rownames = FALSE
        )
      } else {
        DT::datatable(data.frame())
      }
    } else {
      DT::datatable(data.frame())
    }
  })
  
  # 显示详细结果
  output$detailed_results <- renderUI({
    if (length(results_store) > 0) {
      result_id <- names(results_store)[length(results_store)]
      result <- results_store[[result_id]]
      
      tags$div(
        tags$h4("详细结果"),
        tags$p("分析类型:", result_id),
        tags$p("创建时间:", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
        
        if ("significant_genes" %in% names(result)) {
          tags$p("显著基因数量:", nrow(result$significant_genes))
        },
        
        if ("significant_pathways" %in% names(result)) {
          tags$p("显著通路数量:", nrow(result$significant_pathways))
        }
      )
    } else {
      tags$p("暂无详细结果")
    }
  })
  
  # 生成图表
  observeEvent(input$plot_button, {
    req(length(results_store) > 0)
    
    result_id <- names(results_store)[length(results_store)]
    result <- results_store[[result_id]]
    
    # 显示加载状态
    showNotification("正在生成图表...", duration = 2, type = "message")
    
    # 模拟生成过程
    Sys.sleep(1)
    
    # 根据图表类型生成图表
    plot_type <- input$plot_type
    
    if (plot_type == "volcano") {
      # 火山图
      plot <- ggplot(result$significant_genes, aes(x = log2FoldChange, y = -log10(pvalue))) +
        geom_point(aes(color = ifelse(pvalue < 0.05 & abs(log2FoldChange) > 1, "significant", "not_significant")), 
                  size = 3, alpha = 0.7) +
        scale_color_manual(values = c("not_significant" = "gray", "significant" = "red")) +
        geom_hline(yintercept = -log10(input$plot_p_value), linetype = "dashed", color = "red") +
        geom_vline(xintercept = input$plot_log2fc, linetype = "dashed", color = "red") +
        geom_vline(xintercept = -input$plot_log2fc, linetype = "dashed", color = "red") +
        labs(title = "火山图", x = "log2 Fold Change", y = "-log10(p-value)") +
        theme_minimal() +
        theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"))
      
    } else if (plot_type == "heatmap") {
      # 热图
      set.seed(123)
      heatmap_data <- matrix(rnorm(input$n_genes * 10, mean = 0, sd = 1), 
                           nrow = input$n_genes, ncol = 10)
      rownames(heatmap_data) <- paste0("Gene", 1:input$n_genes)
      colnames(heatmap_data) <- paste0("Sample", 1:10)
      
      plot <- pheatmap::pheatmap(
        heatmap_data,
        scale = "row",
        color = RColorBrewer::brewer.pal(11, input$color_palette),
        main = "热图",
        fontsize = 8,
        show_rownames = FALSE,
        show_colnames = FALSE
      )
      
    } else if (plot_type == "scatter") {
      # 散点图
      plot <- ggplot(result$significant_genes, aes(x = log2FoldChange, y = pvalue)) +
        geom_point(size = 3, alpha = 0.7, color = "blue") +
        labs(title = "散点图", x = "log2 Fold Change", y = "p-value") +
        theme_minimal() +
        theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"))
      
    } else if (plot_type == "bar") {
      # 柱状图
      plot <- ggplot(result$significant_pathways[1:20, ], aes(x = reorder(ID, -pvalue), y = -log10(pvalue))) +
        geom_bar(fill = "steelblue", width = 0.8) +
        coord_flip() +
        labs(title = "通路富集分析", x = "通路", y = "-log10(p-value)") +
        theme_minimal() +
        theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"))
      
    } else if (plot_type == "pca") {
      # PCA图
      set.seed(123)
      pca_data <- data.frame(
        PC1 = rnorm(20, mean = 0, sd = 1),
        PC2 = rnorm(20, mean = 0, sd = 1),
        group = rep(c("A", "B"), each = 10)
      )
      
      plot <- ggplot(pca_data, aes(x = PC1, y = PC2, color = group)) +
        geom_point(size = 3, alpha = 0.7) +
        labs(title = "PCA图", x = "PC1", y = "PC2") +
        theme_minimal() +
        theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"))
      
    } else if (plot_type == "dendrogram") {
      # 聚类树图
      set.seed(123)
      hc <- hclust(dist(matrix(rnorm(20*10), nrow=20), method = "euclidean"), method = "ward.D2")
      
      plot <- ggplot(as.data.frame(hc$height), aes(x = seq_along(hc$height), y = hc$height)) +
        geom_line() +
        labs(title = "聚类树图", x = "样本", y = "距离") +
        theme_minimal() +
        theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"))
    }
    
    # 显示图表
    output$main_plot <- renderPlot({
      print(plot)
    }, height = 600)
    
    showNotification("图表生成成功!", duration = 3, type = "success")
  })
  
  # 结果导出处理
  observe({
    # 更新结果选择器
    result_choices <- c("请选择结果" = "", names(results_store))
    updateSelectInput(session, "result_id", choices = result_choices)
  })
  
  observeEvent(input$export_button, {
    req(input$result_id, input$result_id != "")
    
    result_id <- input$result_id
    output_path <- input$output_path
    
    # 显示加载状态
    showNotification("正在导出结果...", duration = 2, type = "message")
    
    # 模拟导出过程
    Sys.sleep(2)
    
    # 创建输出目录
    dir.create(output_path, recursive = TRUE, showWarnings = FALSE)
    
    # 导出结果文件
    result <- results_store[[result_id]]
    
    if ("significant_genes" %in% names(result)) {
      genes_file <- file.path(output_path, "significant_genes.csv")
      write.csv(result$significant_genes, genes_file, row.names = FALSE)
    }
    
    if ("significant_pathways" %in% names(result)) {
      pathways_file <- file.path(output_path, "significant_pathways.csv")
      write.csv(result$significant_pathways, pathways_file, row.names = FALSE)
    }
    
    # 导出统计信息
    summary_file <- file.path(output_path, "analysis_summary.txt")
    writeLines(c(
      "分析结果摘要",
      "=============",
      paste("分析类型:", result_id),
      paste("创建时间:", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
      "",
      "统计信息:"
    ), summary_file)
    
    if ("summary" %in% names(result)) {
      writeLines(capture.output(print(result$summary)), summary_file, append = TRUE)
    }
    
    # 显示导出状态
    output$export_status <- renderUI({
      tags$div(
        class = "alert alert-success",
        tags$h4("导出成功!"),
        tags$p("结果已导出到:", output_path),
        tags$p("导出的文件:"),
        tags$ul(
          tags$li("significant_genes.csv"),
          tags$li("significant_pathways.csv"),
          tags$li("analysis_summary.txt")
        )
      )
    })
    
    showNotification("结果导出成功!", duration = 3, type = "success")
  })
  
  # 选择数据函数（JavaScript）
  output$js_select_data <- renderUI({
    tags$script("
      function selectData(dataId) {
        Shiny.onInputChange('data_selected', dataId);
      }
    ")
  })
}