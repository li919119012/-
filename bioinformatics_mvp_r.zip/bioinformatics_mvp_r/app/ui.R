#' Shiny Web界面 - UI部分
#'
#' @description 生物信息学分析平台的Web界面UI
#' @export

library(shiny)
library(shinydashboard)
library(shinyjs)
library(DT)
library(ggplot2)

# 定义UI
ui <- dashboardPage(
  # 应用标题
  dashboardHeader(
    title = "智能生物信息学分析平台",
    titleWidth = 300
  ),
  
  # 侧边栏
  dashboardSidebar(
    sidebarMenu(
      # 菜单项
      menuItem("数据上传", tabName = "data_upload", icon = icon("upload")),
      menuItem("数据分析", tabName = "data_analysis", icon = icon("chart-line")),
      menuItem("数据可视化", tabName = "data_visualization", icon = icon("bar-chart")),
      menuItem("结果导出", tabName = "result_export", icon = icon("download")),
      menuItem("使用说明", tabName = "help", icon = icon("question-circle"))
    )
  ),
  
  # 主内容区域
  dashboardBody(
    # 使用shinyjs
    useShinyjs(),
    
    # 添加CSS样式
    tags$style(
      HTML("
        .box {
          border-radius: 5px;
          border: 1px solid #ddd;
          box-shadow: 0 2px 5px rgba(0,0,0,0.1);
          margin-bottom: 20px;
        }
        
        .box-title {
          background-color: #f8f9fa;
          border-bottom: 1px solid #ddd;
          padding: 10px 15px;
          font-weight: bold;
          border-radius: 5px 5px 0 0;
        }
        
        .box-content {
          padding: 15px;
        }
        
        .status-success {
          color: #28a745;
          font-weight: bold;
        }
        
        .status-error {
          color: #dc3545;
          font-weight: bold;
        }
        
        .status-warning {
          color: #ffc107;
          font-weight: bold;
        }
        
        .loading {
          text-align: center;
          padding: 20px;
        }
        
        .loading-spinner {
          border: 4px solid #f3f3f3;
          border-top: 4px solid #3498db;
          border-radius: 50%;
          width: 40px;
          height: 40px;
          animation: spin 2s linear infinite;
          margin: 0 auto;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      ")
    ),
    
    # 数据上传标签页
    tabItems(
      # 数据上传页面
      tabItem(
        tabName = "data_upload",
        fluidRow(
          column(12,
            box(
              title = "数据上传",
              width = 12,
              status = "primary",
              solidHeader = TRUE,
              collapsible = TRUE,
              tags$div(
                class = "row",
                div(class = "col-md-6",
                  fileInput(
                    "data_file",
                    "选择数据文件:",
                    accept = c(".csv", ".xlsx", ".tsv"),
                    multiple = FALSE,
                    buttonLabel = "选择文件",
                    placeholder = "未选择文件"
                  )
                ),
                div(class = "col-md-6",
                  selectInput(
                    "data_type",
                    "数据类型:",
                    choices = c("表达数据", "甲基化数据", "临床数据"),
                    selected = "表达数据",
                    width = "100%"
                  )
                )
              ),
              br(),
              div(
                style = "text-align: center;",
                actionButton(
                  "upload_button",
                  "上传数据",
                  icon = icon("upload"),
                  class = "btn-primary",
                  style = "padding: 10px 20px; font-size: 16px;"
                )
              )
            )
          )
        ),
        
        fluidRow(
          column(12,
            box(
              title = "已上传数据",
              width = 12,
              status = "success",
              solidHeader = TRUE,
              collapsible = TRUE,
              DT::dataTableOutput("data_table")
            )
          )
        )
      ),
      
      # 数据分析页面
      tabItem(
        tabName = "data_analysis",
        fluidRow(
          column(4,
            box(
              title = "分析设置",
              width = 12,
              status = "primary",
              solidHeader = TRUE,
              collapsible = TRUE,
              selectInput(
                "analysis_type",
                "分析类型:",
                choices = c(
                  "差异表达分析" = "differential_expression",
                  "基因聚类分析" = "gene_clustering",
                  "样本聚类分析" = "sample_clustering",
                  "通路分析" = "pathway_analysis"
                ),
                selected = "differential_expression"
              ),
              br(),
              
              # 差异表达分析参数
              conditionalPanel(
                condition = "input.analysis_type == 'differential_expression'",
                div(
                  class = "form-group",
                  tags$label("p值阈值:"),
                  numericInput(
                    "p_value_threshold",
                    NULL,
                    value = 0.05,
                    min = 0.001,
                    max = 1,
                    step = 0.001,
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("log2FC阈值:"),
                  numericInput(
                    "log2fc_threshold",
                    NULL,
                    value = 1,
                    min = 0.1,
                    max = 5,
                    step = 0.1,
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("分析方法:"),
                  selectInput(
                    "analysis_method",
                    NULL,
                    choices = c("DESeq2", "edgeR", "limma"),
                    selected = "DESeq2",
                    width = "100%"
                  )
                )
              ),
              
              # 聚类分析参数
              conditionalPanel(
                condition = "input.analysis_type == 'gene_clustering' || input.analysis_type == 'sample_clustering'",
                div(
                  class = "form-group",
                  tags$label("聚类数量:"),
                  numericInput(
                    "n_clusters",
                    NULL,
                    value = 5,
                    min = 2,
                    max = 10,
                    step = 1,
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("聚类方法:"),
                  selectInput(
                    "cluster_method",
                    NULL,
                    choices = c("kmeans", "层次聚类"),
                    selected = "kmeans",
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("距离方法:"),
                  selectInput(
                    "distance_method",
                    NULL,
                    choices = c("欧氏距离", "相关距离"),
                    selected = "欧氏距离",
                    width = "100%"
                  )
                )
              ),
              
              # 通路分析参数
              conditionalPanel(
                condition = "input.analysis_type == 'pathway_analysis'",
                div(
                  class = "form-group",
                  tags$label("p值阈值:"),
                  numericInput(
                    "pathway_p_value",
                    NULL,
                    value = 0.05,
                    min = 0.001,
                    max = 1,
                    step = 0.001,
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("最少基因数:"),
                  numericInput(
                    "min_genes",
                    NULL,
                    value = 5,
                    min = 1,
                    max = 50,
                    step = 1,
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("数据库:"),
                  selectInput(
                    "database",
                    NULL,
                    choices = c("KEGG", "GO"),
                    selected = "KEGG",
                    width = "100%"
                  )
                )
              ),
              
              br(),
              div(
                style = "text-align: center;",
                actionButton(
                  "analyze_button",
                  "开始分析",
                  icon = icon("play"),
                  class = "btn-success",
                  style = "padding: 10px 20px; font-size: 16px;"
                )
              )
            )
          ),
          
          column(8,
            box(
              title = "分析结果",
              width = 12,
              status = "success",
              solidHeader = TRUE,
              collapsible = TRUE,
              tabsetPanel(
                tabPanel(
                  "统计信息",
                  verbatimTextOutput("analysis_summary")
                ),
                tabPanel(
                  "显著基因",
                  DT::dataTableOutput("significant_genes")
                ),
                tabPanel(
                  "通路结果",
                  DT::dataTableOutput("pathway_results")
                ),
                tabPanel(
                  "详细结果",
                  htmlOutput("detailed_results")
                )
              )
            )
          )
        )
      ),
      
      # 数据可视化页面
      tabItem(
        tabName = "data_visualization",
        fluidRow(
          column(4,
            box(
              title = "可视化设置",
              width = 12,
              status = "primary",
              solidHeader = TRUE,
              collapsible = TRUE,
              selectInput(
                "plot_type",
                "图表类型:",
                choices = c(
                  "火山图" = "volcano",
                  "热图" = "heatmap",
                  "散点图" = "scatter",
                  "柱状图" = "bar",
                  "PCA图" = "pca",
                  "聚类树图" = "dendrogram"
                ),
                selected = "volcano"
              ),
              br(),
              
              # 火山图参数
              conditionalPanel(
                condition = "input.plot_type == 'volcano'",
                div(
                  class = "form-group",
                  tags$label("p值阈值:"),
                  numericInput(
                    "plot_p_value",
                    NULL,
                    value = 0.05,
                    min = 0.001,
                    max = 1,
                    step = 0.001,
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("log2FC阈值:"),
                  numericInput(
                    "plot_log2fc",
                    NULL,
                    value = 1,
                    min = 0.1,
                    max = 5,
                    step = 0.1,
                    width = "100%"
                  )
                )
              ),
              
              # 热图参数
              conditionalPanel(
                condition = "input.plot_type == 'heatmap'",
                div(
                  class = "form-group",
                  tags$label("显示基因数:"),
                  numericInput(
                    "n_genes",
                    NULL,
                    value = 50,
                    min = 10,
                    max = 200,
                    step = 10,
                    width = "100%"
                  )
                ),
                div(
                  class = "form-group",
                  tags$label("颜色方案:"),
                  selectInput(
                    "color_palette",
                    NULL,
                    choices = c("RdBu", "PuOr", "BrBG", "PiYG"),
                    selected = "RdBu",
                    width = "100%"
                  )
                )
              ),
              
              # PCA参数
              conditionalPanel(
                condition = "input.plot_type == 'pca'",
                div(
                  class = "form-group",
                  tags$label("分组变量:"),
                  selectInput(
                    "pca_group",
                    NULL,
                    choices = c("无分组", "分组1", "分组2"),
                    selected = "无分组",
                    width = "100%"
                  )
                )
              ),
              
              br(),
              div(
                style = "text-align: center;",
                actionButton(
                  "plot_button",
                  "生成图表",
                  icon = icon("bar-chart"),
                  class = "btn-info",
                  style = "padding: 10px 20px; font-size: 16px;"
                )
              )
            )
          ),
          
          column(8,
            box(
              title = "可视化结果",
              width = 12,
              status = "success",
              solidHeader = TRUE,
              collapsible = TRUE,
              plotOutput("main_plot", height = "600px")
            )
          )
        )
      ),
      
      # 结果导出页面
      tabItem(
        tabName = "result_export",
        fluidRow(
          column(12,
            box(
              title = "结果导出",
              width = 12,
              status = "primary",
              solidHeader = TRUE,
              collapsible = TRUE,
              div(
                class = "row",
                div(class = "col-md-6",
                  selectInput(
                    "result_id",
                    "选择结果:",
                    choices = character(0),
                    width = "100%"
                  )
                ),
                div(class = "col-md-6",
                  textInput(
                    "output_path",
                    "输出路径:",
                    value = "./results",
                    width = "100%"
                  )
                )
              ),
              br(),
              div(
                style = "text-align: center;",
                actionButton(
                  "export_button",
                  "导出结果",
                  icon = icon("download"),
                  class = "btn-success",
                  style = "padding: 10px 20px; font-size: 16px;"
                )
              )
            )
          )
        ),
        
        fluidRow(
          column(12,
            box(
              title = "导出结果",
              width = 12,
              status = "success",
              solidHeader = TRUE,
              collapsible = TRUE,
              uiOutput("export_status")
            )
          )
        )
      ),
      
      # 使用说明页面
      tabItem(
        tabName = "help",
        fluidRow(
          column(12,
            box(
              title = "使用说明",
              width = 12,
              status = "info",
              solidHeader = TRUE,
              collapsible = TRUE,
              includeMarkdown("help.md")
            )
          )
        )
      )
    )
  )
)