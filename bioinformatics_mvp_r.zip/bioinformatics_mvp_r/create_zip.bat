@echo off
echo 创建生物信息学分析平台压缩包...
echo.

REM 创建临时目录
set temp_dir=%temp%\bioinformatics_mvp_r
if exist "%temp_dir%" rmdir /s /q "%temp_dir%"
mkdir "%temp_dir%"

REM 复制项目文件
echo 复制项目文件...
xcopy /E /I /H "%~dp0" "%temp_dir%"

REM 创建桌面目录
set desktop_dir=%USERPROFILE%\Desktop
set target_dir="%desktop_dir%\bioinformatics_mvp_r"

REM 检查桌面目录是否存在
if not exist "%desktop_dir%" (
    echo 桌面目录不存在，创建目录...
    mkdir "%desktop_dir%"
)

REM 复制到桌面
echo 复制到桌面: %target_dir%
xcopy /E /I /H "%temp_dir%" "%target_dir%"

REM 创建启动脚本
echo 创建启动脚本...
echo @echo off > "%target_dir%\start.bat"
echo echo 启动智能生物信息学分析平台... >> "%target_dir%\start.bat"
echo echo 访问地址: http://localhost:8080 >> "%target_dir%\start.bat"
echo echo 按 Ctrl+C 停止服务 >> "%target_dir%\start.bat"
echo echo. >> "%target_dir%\start.bat"
echo Rscript run_app.bat >> "%target_dir%\start.bat"

REM 创建安装脚本
echo 创建安装脚本...
echo @echo off > "%target_dir%\install.bat"
echo echo 安装依赖包... >> "%target_dir%\install.bat"
echo echo 这可能需要几分钟时间... >> "%target_dir%\install.bat"
echo echo. >> "%target_dir%\install.bat"
echo Rscript -e "install.packages(c('shiny', 'shinydashboard', 'DT', 'ggplot2', 'plotly', 'pheatmap', 'ggpubr', 'RColorBrewer', 'viridis', 'data.table', 'dplyr', 'tidyr'))" >> "%target_dir%\install.bat"
echo Rscript -e "if (!require('BiocManager', quietly = TRUE)) install.packages('BiocManager')" >> "%target_dir%\install.bat"
echo Rscript -e "BiocManager::install(c('DESeq2', 'edgeR', 'limma', 'cluster', 'factoextra', 'org.Hs.eg.db', 'clusterProfiler', 'pathview', 'enrichplot', 'biomaRt', 'AnnotationDbi'))" >> "%target_dir%\install.bat"
echo. >> "%target_dir%\install.bat"
echo echo 安装完成! >> "%target_dir%\install.bat"
echo echo 请运行 start.bat 启动应用 >> "%target_dir%\install.bat"

REM 创建使用说明
echo 创建使用说明...
echo # 智能生物信息学分析平台 - 快速使用指南 > "%target_dir%\QUICK_START.md"
echo. >> "%target_dir%\QUICK_START.md"
echo ## 快速开始 >> "%target_dir%\QUICK_START.md"
echo. >> "%target_dir%\QUICK_START.md"
echo 1. **安装依赖**: 双击运行 `install.bat` >> "%target_dir%\QUICK_START.md"
echo 2. **启动应用**: 双击运行 `start.bat` >> "%target_dir%\QUICK_START.md"
echo 3. **访问应用**: 打开浏览器访问 `http://localhost:8080` >> "%target_dir%\QUICK_START.md"
echo. >> "%target_dir%\QUICK_START.md"
echo ## 功能介绍 >> "%target_dir%\QUICK_START.md"
echo. >> "%target_dir%\QUICK_START.md"
echo - **数据上传**: 支持CSV、Excel、TSV格式的数据文件 >> "%target_dir%\QUICK_START.md"
echo - **数据分析**: 差异表达分析、聚类分析、通路分析 >> "%target_dir%\QUICK_START.md"
echo - **数据可视化**: 火山图、热图、散点图、PCA图等 >> "%target_dir%\QUICK_START.md"
echo - **结果导出**: 支持CSV格式导出 >> "%target_dir%\QUICK_START.md"
echo. >> "%target_dir%\QUICK_START.md"
echo ## 注意事项 >> "%target_dir%\QUICK_START_START.md"
echo. >> "%target_dir%\QUICK_START.md"
echo - 确保已安装R语言 (R 4.0+) >> "%target_dir%\QUICK_START.md"
echo - 首次运行需要安装依赖包，请耐心等待 >> "%target_dir%\QUICK_START.md"
echo - 如遇到问题，请查看 `README.md` 文件 >> "%target_dir%\QUICK_START.md"

REM 创建完成提示
echo.
echo ========================================
echo 生物信息学分析平台已创建完成!
echo.
echo 位置: %target_dir%
echo.
echo 使用方法:
echo 1. 双击运行 install.bat 安装依赖
echo 2. 双击运行 start.bat 启动应用
echo 3. 打开浏览器访问 http://localhost:8080
echo.
echo 详细说明请查看 README.md 文件
echo ========================================

REM 清理临时目录
rmdir /s /q "%temp_dir%"

pause