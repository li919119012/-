@echo off
echo 安装依赖包...
echo 这可能需要几分钟时间...
echo.

echo 安装基础R包...
Rscript -e "install.packages(c('shiny', 'shinydashboard', 'DT', 'ggplot2', 'plotly', 'pheatmap', 'ggpubr', 'RColorBrewer', 'viridis', 'data.table', 'dplyr', 'tidyr'))"

echo 安装BiocManager...
Rscript -e "if (!require('BiocManager', quietly = TRUE)) install.packages('BiocManager')"

echo 安装生物信息学包...
Rscript -e "BiocManager::install(c('DESeq2', 'edgeR', 'limma', 'cluster', 'factoextra', 'org.Hs.eg.db', 'clusterProfiler', 'pathview', 'enrichplot', 'biomaRt', 'AnnotationDbi'))"

echo.
echo 安装完成!
echo 请运行 start.bat 启动应用

pause